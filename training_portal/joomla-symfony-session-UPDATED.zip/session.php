<?php

define( '_JEXEC', 1 );
define( 'JPATH_BASE', realpath(dirname(__FILE__) ));
 
require_once ( JPATH_BASE .'/includes/defines.php' );
require_once ( JPATH_BASE .'/includes/framework.php' );
require_once ( JPATH_BASE .'/Ldap_Li.php' );

$mainframe = JFactory::getApplication('site');
$mainframe->initialise();
$session = JFactory::getSession();
$user = JFactory::getUser();



	if(isset($_GET['do']) && $_GET['do'] == 'logout')
	{
	_logout($user->id);
        header("Location: http://localhost/joomla/session.php");
        exit;
	}




	if($user->guest)
        {
            echo 'user is logged out ';
    		// user is logged out
		//do user logged out stuff
                
               // clear symfony session data
            if(isset($_SESSION) &&  isset($_SESSION["user_roles"]) )
            session_unset("user_roles"); 
	}
	else
        {
            echo 'user is logged in ';
		// user is logged in 
		//do user logged in stuff
	if ($session->getState() != 'expired')
	{
    
	$auth_type = $user->getParam('auth_type');

	if( strtolower($auth_type) == 'ldap')
	{
            echo 'using ldap Auth , ';
	$user_data = get_userdata_by_username($user->get('username'));
	//print_r($user_data);
        
        // get roles
        // set role into the session

        $_SESSION["user_roles"] = array(1,2);
        
        echo '<a href="http://localhost/joomla/session.php?do=logout">logout</a>';
	}
        
	}
        
        
	}
        
        //-----------------------------------------------------------------
        
	function get_userdata_by_username($username)
	{
  		  // get user data
			$ldap = new Ldap_Li();
			$user_data = array();
			$Filter         = "sAMAccountName=".$username."*";
			$SearchAttribut = array("cn","displayname","wwwhomepage","title","ipphone","mail","telephonenumber");
			if($s_result= $ldap->_search($Filter, $SearchAttribut ))
			     {
                                
                             // usename
                             $user_data['username']= $username;
                             
                             // full name in english 
    			     if(isset($s_result[0]["displayname"][0]))
      			     $user_data['en_fullname']= $s_result[0]["displayname"][0];
                             
                             // full name in arabic 
        		     if(isset($s_result[0]["wwwhomepage"][0]))
      			     $user_data['ar_fullname']= $s_result[0]["wwwhomepage"][0];
                             
                             // job title
      			     if(isset($s_result[0]["title"][0]))
      			     $user_data['job_title']= $s_result[0]["title"][0];
                             
                             // employee number 
      			     if(isset($s_result[0]["ipphone"][0]))
      			     $user_data['employee_no']= $s_result[0]["ipphone"][0];
                             
                             // email address
      			     if(isset($s_result[0]["mail"][0]))
      			     $user_data['mail']= $s_result[0]["mail"][0];
                             
                             // extinsion number 
      			     if(isset($s_result[0]["telephonenumber"][0])) 
      			     $user_data['extension_no']= substr($s_result[0]["telephonenumber"][0], -4 );
          

      			     }
                             
                             return $user_data;
        }
        
        //------------------------------------------------------
        
        function _logout($userid)
        {
            // logout from joomla
                $app = JFactory::getApplication();
                $app->logout($userid);
            // clear symfony session data
            if(isset($_SESSION) &&  isset($_SESSION["user_roles"]) )
            session_unset("user_roles"); 

        }

?>