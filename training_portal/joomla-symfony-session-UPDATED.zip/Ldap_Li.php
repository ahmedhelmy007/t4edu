<?php

class Ldap_Li
{
	// register properties
	private $_hosts;
	private $_ports;
	private $_base_dn;
	private $_ad_domain;
	private $_ldap_bind;
	private $_admin_user;
	private $_admin_pass;
	private $_ldap_conn;
	
	/**
     * @access public
     */
	function __construct() 
	{
		// perform the secondary initialisation
		$this->_init();
	}

 /*
  *  
  * _init
  * initiate ldap connection 
  * @params :-
  * return : -
  */

	private function _init() 
	{
		// check for an active LDAP extension
		if (!function_exists('ldap_connect')) 
		{
			log_message('error', 'Auth_AD: LDAP PHP module not found.');
			show_error('LDAP PHP module not found. Please ensure that the module is loaded or compiled in.');
		}
		
		// register the configuration variables as properties
		$this->_hosts      = '172.16.133.11';
		$this->_ports      = 389;
		$this->_base_dn    = "OU=T4edu Users,DC=tatweer,DC=edu,DC=sa";;
		$this->_ad_domain  = 'tatweer.edu.sa';
		$this->_admin_user = 'sharepoint';
		$this->_admin_pass = 'P@$swor2007Tatwr@97182';
		
		$this->_connect();
	}
	
 /*
  *  
  * _connect
  * connect to the active directory 
  * @params :-
  * return : -
  */

	function _connect()
	{
		$this->_ldap_conn=ldap_connect($this->_hosts, $this->_ports);
		ldap_set_option($this->_ldap_conn, LDAP_OPT_PROTOCOL_VERSION, 3);
		ldap_set_option($this->_ldap_conn, LDAP_OPT_REFERRALS, 0);

		$dn="ou=T4edu Users,".$this->_base_dn;
		$this->_ldap_bind=ldap_bind($this->_ldap_conn, $this->_admin_user .'@' .$this->_ad_domain, $this->_admin_pass);
		//if($this->_ldap_bind) echo 'connected'; 
	}
	
	
 /*
  *  
  * _search
  * search the active directory 
  * @params :
  * $filter : filter string
  * $serch_q : array of attributes to search for 
  * return : object of data if true or false if not 
  */
	function _search($filter, $serch_q  )
	{
		
	 //$result = ldap_search($this->_ldap_conn,$this->_base_dn, $filter , $serch_q) or die ("Error in search query: ".ldap_error($this->_ldap_conn)); // search all levels 
         $result = ldap_list($this->_ldap_conn,$this->_base_dn, $filter , $serch_q); // search one level
	 $data = ldap_get_entries($this->_ldap_conn, $result);
	 if($data["count"] >0 )
	 return $data;
	
	return false;
	}
	
	
 /*
  *  
  * get_departments
  * get all departments
  * @params :-
  * return : array of departments 
  */

	function get_departments()
	{
		if($s_result= $this->_search("(cn=*)",  array("department") ))
		{
        		for ($i=0; $i<$s_result["count"]; $i++) {
           		 if(isset($s_result[$i]["department"][0]))
          		  $all_deps[]=$s_result[$i]["department"][0];
      			  }
       			 $all_deps = array_unique($all_deps);
			
			return $all_deps;
		}
		 
	}
	
 /*
  *  
  * get_users_from_department
  * get all users related to the selected department
  * @params :
  * $ddep : department name as a string 
  * return : array of users
  */

	function get_users_from_department($ddep)
	{
	
	
	$startFilter        = "department=$ddep*";
		if($s_result= $this->_search($startFilter, array("cn","department","objectguid") ))
		{
			$k=0;
			 
        		for ($i=0; $i<$s_result["count"]; $i++) {
           		 if(isset($s_result[$i]["cn"][0]) && isset($s_result[$i]["objectguid"][0]) )
          		  $all_users[$k]['userguid']=bin2hex($s_result[$i]["objectguid"][0]);
			  
			  $all_users[$k]['username']=$s_result[$i]["cn"][0];
			  $k++;
      			  }
       			 
		 
			return $all_users;
		//print_r($all_users);
		}
		 
	}
	
 /*
  *  
  * _login
  * login user into the system using his active directory login data
  * @params :
  * $username : username as string
  * $password : password as string
  * return : array of usersdata if true , false if not 
  */

	function _login($username,$password)
	{
		                  // verify user and password
  	  if(@ldap_bind($this->_ldap_conn, $username .'@' . $this->_ad_domain, $password)) {
      	  // valid
      	  // check presence in groups
       	  $filter = "(sAMAccountName=" . $username . ")";
      	  $attr = array("objectguid","displayname","department");
	 
	  if( $result = $this->_search($filter, $attr))
	  {
		
		return array('id'=> bin2hex($result[0]["objectguid"][0]) , 'username' => $username ,'full_name' => $result[0]["displayname"][0] , "department" => $result[0]["department"][0]);
	  }
	else
	return false;
    }
    else
    return false ;
	}

}

